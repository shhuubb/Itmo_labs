package Utility;
/**
 * Интерфейс для проверки валидности данных
 * @author sh_ub
 */
public interface Validatable {
    public boolean validate();
}
