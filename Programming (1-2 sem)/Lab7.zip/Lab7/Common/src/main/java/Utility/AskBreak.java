package Utility;
/**
 * Исключение для выхода и программы
 * @author sh_ub
 */
public class AskBreak extends Exception {}
